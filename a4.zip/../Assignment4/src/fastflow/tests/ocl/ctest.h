/*
 * ctest.h
 *
 *  Created on: Aug 7, 2015
 *      Author: mdrocco
 */

#ifndef TESTS_OCL_CTEST_H_
#define TESTS_OCL_CTEST_H_


#define SET_DEVICE_TYPE(obj) obj.pickGPU();
#define NACC 1

//#define SET_DEVICE_TYPE(obj) obj.pickCPU();
//#define NACC 1


#endif /* TESTS_OCL_CTEST_H_ */
